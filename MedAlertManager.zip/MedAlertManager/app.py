from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, make_response
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity, set_access_cookies, unset_jwt_cookies, verify_jwt_in_request
from flask_cors import CORS
from datetime import datetime, timedelta
from functools import wraps
import uuid
import os
import json
from replit import db

app = Flask(__name__)
CORS(app)

app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'alarmed-secret-key-dev')
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'alarmed-jwt-secret-key-dev')
app.config['JWT_TOKEN_LOCATION'] = ['cookies']
app.config['JWT_COOKIE_SECURE'] = False
app.config['JWT_COOKIE_CSRF_PROTECT'] = False
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)

jwt = JWTManager(app)

# Inicializar estruturas no database se não existirem
if "users" not in db:
    db["users"] = {}
if "medications" not in db:
    db["medications"] = {}


class User:
    def __init__(self, name, email, age, weight, password):
        self.id = str(uuid.uuid4())
        self.name = name
        self.email = email
        self.age = age
        self.weight = weight
        self.password = password
        self.created_at = datetime.now()

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'age': self.age,
            'weight': self.weight,
            'password': self.password,
            'created_at': self.created_at.isoformat()
        }


class Medication:
    def __init__(self, user_id, name, med_type, dosage, schedule, alerts, notes):
        self.id = str(uuid.uuid4())
        self.user_id = user_id
        self.name = name
        self.type = med_type
        self.dosage = dosage
        self.schedule = schedule
        self.alerts = alerts
        self.notes = notes
        self.created_at = datetime.now()

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'name': self.name,
            'type': self.type,
            'dosage': self.dosage,
            'schedule': self.schedule,
            'alerts': self.alerts,
            'notes': self.notes,
            'created_at': self.created_at.isoformat()
        }


def web_jwt_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            verify_jwt_in_request()
            return f(*args, **kwargs)
        except:
            return redirect(url_for('index'))
    return decorated_function


@app.route('/health')
def health():
    return jsonify({'status': 'ok', 'app': 'AlarMed'}), 200


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/dashboard')
@web_jwt_required
def dashboard():
    user_id = get_jwt_identity()
    medications = dict(db["medications"])
    user_medications = [med for med in medications.values() if med['user_id'] == user_id]
    users = dict(db["users"])
    user = users.get(user_id)
    return render_template('dashboard.html', medications=user_medications, user=user)


@app.route('/medications/add')
@web_jwt_required
def add_medication_page():
    return render_template('add_medication.html')


@app.route('/medications/history')
@web_jwt_required
def history():
    user_id = get_jwt_identity()
    medications = dict(db["medications"])
    user_medications = [med for med in medications.values() if med['user_id'] == user_id]
    user_medications.sort(key=lambda x: x['created_at'], reverse=True)
    return render_template('history.html', medications=user_medications)


@app.route('/medications/edit/<medication_id>')
@web_jwt_required
def edit_medication_page(medication_id):
    medications = dict(db["medications"])
    medication = medications.get(medication_id)
    user_id = get_jwt_identity()
    
    if not medication or medication['user_id'] != user_id:
        flash('Medicamento não encontrado.', 'error')
        return redirect(url_for('dashboard'))
    
    return render_template('edit_medication.html', medication=medication)


@app.route('/logout')
def logout():
    response = make_response(redirect(url_for('index')))
    unset_jwt_cookies(response)
    flash('Logout realizado com sucesso!', 'success')
    return response


@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json()
    
    if not all(k in data for k in ['name', 'email', 'age', 'weight', 'password']):
        return jsonify({'error': 'Campos obrigatórios faltando'}), 400
    
    users = dict(db["users"])
    if any(user['email'] == data['email'] for user in users.values()):
        return jsonify({'error': 'Email já cadastrado'}), 400
    
    try:
        age = int(data['age'])
        weight = float(data['weight'])
        
        if age < 0 or age > 150:
            return jsonify({'error': 'Idade inválida'}), 400
        if weight <= 0 or weight > 500:
            return jsonify({'error': 'Peso inválido'}), 400
            
    except ValueError:
        return jsonify({'error': 'Idade ou peso inválido'}), 400
    
    user = User(
        name=data['name'],
        email=data['email'],
        age=age,
        weight=weight,
        password=data['password']
    )
    
    users[user.id] = user.to_dict()
    db["users"] = users
    
    access_token = create_access_token(identity=user.id)
    
    response = jsonify({
        'message': 'Usuário cadastrado com sucesso!',
        'user': user.to_dict()
    })
    
    set_access_cookies(response, access_token)
    return response, 201


@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not all(k in data for k in ['email', 'password']):
        return jsonify({'error': 'Email e senha são obrigatórios'}), 400
    
    users = dict(db["users"])
    user_data = next((u for u in users.values() if u['email'] == data['email']), None)
    
    if not user_data:
        return jsonify({'error': 'Email ou senha incorretos'}), 401
    
    # Converter ObservedDict para dict comum
    user_dict = dict(user_data)
    
    # Verificar senha
    if user_dict.get('password') != data['password']:
        return jsonify({'error': 'Email ou senha incorretos'}), 401
    
    access_token = create_access_token(identity=user_dict['id'])
    
    response = jsonify({
        'message': 'Login realizado com sucesso!',
        'user': {
            'id': user_dict['id'],
            'name': user_dict['name'],
            'email': user_dict['email'],
            'age': user_dict['age'],
            'weight': user_dict['weight']
        }
    })
    
    set_access_cookies(response, access_token)
    return response, 200


@app.route('/api/medications', methods=['GET'])
@jwt_required()
def get_medications():
    user_id = get_jwt_identity()
    medications = dict(db["medications"])
    user_medications = [med for med in medications.values() if med['user_id'] == user_id]
    return jsonify({'medications': user_medications}), 200


@app.route('/api/medications', methods=['POST'])
@jwt_required()
def create_medication():
    user_id = get_jwt_identity()
    data = request.get_json()
    
    if not all(k in data for k in ['name', 'type', 'dosage', 'schedule']):
        return jsonify({'error': 'Campos obrigatórios faltando'}), 400
    
    if not isinstance(data['schedule'], list) or len(data['schedule']) == 0:
        return jsonify({'error': 'É necessário adicionar pelo menos um horário'}), 400
    
    medication = Medication(
        user_id=user_id,
        name=data['name'],
        med_type=data['type'],
        dosage=data['dosage'],
        schedule=data['schedule'],
        alerts=data.get('alerts', True),
        notes=data.get('notes', '')
    )
    
    medications = dict(db["medications"])
    medications[medication.id] = medication.to_dict()
    db["medications"] = medications
    
    return jsonify({
        'message': 'Medicamento cadastrado com sucesso!',
        'medication': medication.to_dict()
    }), 201


@app.route('/api/medications/<medication_id>', methods=['PUT'])
@jwt_required()
def update_medication(medication_id):
    user_id = get_jwt_identity()
    medications = dict(db["medications"])
    medication = medications.get(medication_id)
    
    if not medication:
        return jsonify({'error': 'Medicamento não encontrado'}), 404
    
    if medication['user_id'] != user_id:
        return jsonify({'error': 'Não autorizado'}), 403
    
    data = request.get_json()
    
    if 'name' in data:
        medication['name'] = data['name']
    if 'type' in data:
        medication['type'] = data['type']
    if 'dosage' in data:
        medication['dosage'] = data['dosage']
    if 'schedule' in data:
        if not isinstance(data['schedule'], list) or len(data['schedule']) == 0:
            return jsonify({'error': 'É necessário adicionar pelo menos um horário'}), 400
        medication['schedule'] = data['schedule']
    if 'alerts' in data:
        medication['alerts'] = data['alerts']
    if 'notes' in data:
        medication['notes'] = data['notes']
    
    medications[medication_id] = medication
    db["medications"] = medications
    
    return jsonify({
        'message': 'Medicamento atualizado com sucesso!',
        'medication': medication
    }), 200


@app.route('/api/medications/<medication_id>', methods=['DELETE'])
@jwt_required()
def delete_medication(medication_id):
    user_id = get_jwt_identity()
    medications = dict(db["medications"])
    medication = medications.get(medication_id)
    
    if not medication:
        return jsonify({'error': 'Medicamento não encontrado'}), 404
    
    if medication['user_id'] != user_id:
        return jsonify({'error': 'Não autorizado'}), 403
    
    del medications[medication_id]
    db["medications"] = medications
    
    return jsonify({'message': 'Medicamento excluído com sucesso!'}), 200


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
